<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" prefix="og: http://ogp.me/ns#">
<head>

<title> <?php echo e($page_title); ?></title>

<!-- Meta
============================================= -->
<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, post-check=0, pre-check=0" />
<meta http-equiv="Expires" content="Sat, 26 Jul 1997 05:00:00 GMT" />

<meta name="description" content=" | Perpustakaan Politeknik Negeri Padang">
<meta name="keywords" content="">
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">
<meta name="generator" content="SLiMS 8.3 (Akasia)">

<!-- Opengraph
============================================= -->
<meta property="og:locale" content="en_US"/>
<meta property="og:type" content="book"/>
<meta property="og:title" content=" | Perpustakaan Politeknik Negeri Padang"/>
<meta property="og:description" content=""/>
<meta property="og:url" content="//e-lib.pnp.ac.id/elib/"/>
<meta property="og:site_name" content="Perpustakaan Politeknik Negeri Padang"/>
<meta property="og:image" content="//e-lib.pnp.ac.id/elib/template/default/img/logo.png"/>

<!-- Twitter
============================================= -->
<meta name="twitter:card" content="summary">
<meta name="twitter:url" content="//e-lib.pnp.ac.id/elib/"/>
<meta name="twitter:title" content=" | Perpustakaan Politeknik Negeri Padang"/>
<meta property="twitter:image" content="//e-lib.pnp.ac.id/elib/template/default/img/logo.png"/>

<!-- Theme
============================================= -->
<link rel="shortcut icon" href="webicon.ico" type="image/x-icon"/>
<link rel="stylesheet" href=" <?php echo e(asset('assets/testing/core.style.css')); ?> " type="text/css" />
<link rel="stylesheet" href="<?php echo e(asset('assets/testing/colorbox.css')); ?>" type="text/css" />
<link rel="profile" href="http://www.slims.web.id/">
<link rel="canonical" href="//e-lib.pnp.ac.id/elib/" />
<meta name="robots" content="index, follow">
<!-- Script
============================================= -->
<script src="<?php echo e(asset('assets/testing/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/modernizr.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/gui.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/highlight.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/fancywebsocket.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/jquery.colorbox-min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/jquery.jcarousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/jquery.transit.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/testing/js/custom.js')); ?>"></script>


<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/testing/style.min.css')); ?>" />



</head>

<body itemscope="itemscope" itemtype="http://schema.org/WebPage">

<!--[if lt IE 9]>
<div class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</div>
<![endif]-->

<header class="s-header container" role="banner">
  <div class="row">
    <div class="col-lg-6">
      <a href="index.php" class="s-brand">
        <img class="s-logo animated flipInY delay7" src="template/default/img/logo.png" alt="Perpustakaan Politeknik Negeri Padang" />
        <h1 class="animated fadeInUp delay2">Perpustakaan Politeknik Negeri Padang</h1>
        <div class="s-brand-tagline animated fadeInUp delay3"></div>
      </a>
    </div>
    <div class="col-6-lg" >
      <div class="s-pmenu">
        <div class="s-menu animated fadeInUp delay4">
          <a href="#" id="show-menu" class="s-menu-toggle" role="navigation"><span></span></a>
        </div>
      </div>
    </div>
  </div>
</header>

<nav class="s-menu-content animated-fast" role="navigation">
  <a href="#" id="hide-menu" class="s-menu-toggle"><span></span></a>
  <h1>Menu</h1>
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="index.php?p=news">Library News</a></li>
    <li><a href="index.php?p=libinfo">Library Information</a></li>
    <li><a href="index.php?p=peta" class="openPopUp" width="600" height="400">Library Location</a></li>
    <li><a href="index.php?p=member">Member Area</a></li>
    <li><a href="index.php?p=perpanjang">Loan Extend</a></li>
    <li><a href="index.php?p=librarian">Librarian</a></li>
    <li><a href="index.php?p=help">Help on Search</a></li>
    <li><a href="index.php?p=login">Librarian LOGIN</a></li>
    <li><a href="index.php?p=slimsinfo">About SLiMS</a></li>
  </ul>

  <!-- Language Translator
  ============================================= -->
  <div class="s-menu-info">
    <form class="language" name="langSelect" action="index.php" method="get">
      <label class="language-info" for="select_lang">Select Language</label>
      <span class="custom-dropdown custom-dropdown--emerald custom-dropdown--small">
        <select name="select_lang" id="select_lang" title="Change language of this site" onchange="document.langSelect.submit();" class="custom-dropdown__select custom-dropdown__select--emerald">
          <option value="ar_AR" >Arabic</option><option value="bn_BD" >Bengali</option><option value="pt_BR" >Brazilian Portuguese</option><option value="en_US" selected>English</option><option value="es_ES" >Espanol</option><option value="de_DE" >German</option><option value="id_ID" >Indonesian</option><option value="ja_JP" >Japanese</option><option value="th_TH" >Thai</option><option value="my_MY" >Malay</option><option value="fa_IR" >Persian</option>        </select>
      </span>
    </form>
  </div>
</nav>


<!-- Homepage
============================================= -->
<main id="content" class="s-main" role="main">

    <!-- Search form
    ============================================= -->
    <div class="s-main-search animated fadeInUp delay1">
      <form action="index.php" method="get" autocomplete="off">
        <h1 class="animated fadeInUp delay2">SEARCH</h1>
        <div class="marquee down">
          <p class="s-search-info">
          start it by typing one or more keywords for title, author or subject          <!--
          use logical search "title=library AND author=robert"          just click on the Search button to see all collections          -->
          </p>
        </div>
        <input type="text" class="s-search animated fadeInUp delay4" id="keyword" name="keywords" value="" lang="en_US" aria-hidden="true" autocomplete="off">
        <button type="submit" name="search" value="search" class="s-btn animated fadeInUp delay4">Search</button>
        <div id="fkbx-spch" tabindex="0" aria-label="Telusuri dengan suara" style="display: block;"></div>
      </form>
    </div>


</main>


<footer class="s-footer">
      <!-- Featured
    ============================================= -->
    <div class="s-feature-content animated fadeInUp delay9">
    <div class="s-feature-list" itemscope itemtype="http://schema.org/Book" vocab="http://schema.org/" typeof="Book">
      <ul id="topbook" class="jcarousel-skin-tango">
                    <li class="book">
              <a itemprop="name" property="name" href="./index.php?p=show_detail&amp;id=10235" title="Aplikasi Program terintegrasi dengan visual basic 6.0">
                <div class="s-feature-title">Aplikasi<br/>Program<br/>...</div>
                <img itemprop="image" src="<?php echo e(asset('assets/testing/testing.jpg')); ?>" alt="Aplikasi Program terintegrasi dengan visual basic 6.0" />
              </a>
            </li>
                        <li class="book">
              <a itemprop="name" property="name" href="./index.php?p=show_detail&amp;id=10234" title="Teknologi Wireless Communication dan wireless Broadband">
                <div class="s-feature-title">Teknologi<br/>Wireless<br/>...</div>
                <img itemprop="image" src="<?php echo e(asset('assets/testing/testing.jpg')); ?>" alt="Teknologi Wireless Communication dan wireless Broadband" />
              </a>
            </li>
                        <li class="book">
              <a itemprop="name" property="name" href="./index.php?p=show_detail&amp;id=10233" title="Pemasaran Jasa konsep dan implementasi">
                <div class="s-feature-title">Pemasaran<br/>Jasa<br/>...</div>
                <img itemprop="image" src="<?php echo e(asset('assets/testing/testing.jpg')); ?>" alt="Pemasaran Jasa konsep dan implementasi" />
              </a>
            </li>
                        <li class="book">
              <a itemprop="name" property="name" href="./index.php?p=show_detail&amp;id=6795" title="research design: rendekatan kualitatif kuantitatif">
                <div class="s-feature-title">research<br/>design:<br/>...</div>
                <img itemprop="image" src="<?php echo e(asset('assets/testing/testing.jpg')); ?>" alt="research design: rendekatan kualitatif kuantitatif" />
              </a>
            </li>
                        <li class="book">
              <a itemprop="name" property="name" href="./index.php?p=show_detail&amp;id=7625" title="Ragam Model dan Penelitian dan Pengolahannya dengan SPSS">
                <img itemprop="image" src="<?php echo e(asset('assets/testing/testing.jpg')); ?>" alt="Ragam Model dan Penelitian dan Pengolahannya dengan SPSS" />
              </a>
            </li>
                        <li class="book">
              <a itemprop="name" property="name" href="./index.php?p=show_detail&amp;id=7643" title="Metode Penelitian Survei">
                <img itemprop="image" src="<?php echo e(asset('assets/testing/testing.jpg')); ?>" alt="Metode Penelitian Survei" />
              </a>
            </li>
                        <li class="book">
              <a itemprop="name" property="name" href="./index.php?p=show_detail&amp;id=10232" title="Akuntansi Keuangan Lanjutan (perspektif Indonesia) ; Advanced Financial Accounting">
                <div class="s-feature-title">Akuntansi<br/>Keuangan<br/>...</div>
                <img itemprop="image" src="<?php echo e(asset('assets/testing/testing.jpg')); ?>" alt="Akuntansi Keuangan Lanjutan (perspektif Indonesia) ; Advanced Financial Accounting" />
              </a>
            </li>
           
                  </ul>
    </div>
    </script>
    </div>
      
  <div class="s-footer-content container">
    <div class="row">
      <div class="col-lg-6 col-sm-3 col-xs-12">
        <div class="s-footer-tagline">
          <a href="//slims.web.id" target="_blank">SLiMS 8.3 (Akasia)</a>
        </div>
      </div>
      <nav class="col-lg-6 col-sm-9 col-xs-12">
        <ul class="s-footer-menu">
          <li><a href="index.php">Home</a></li>
          <li><a target="_blank" rel="archives" href="//www.facebook.com/groups/senayan.slims">Facebook</a></li>
          <li><a target="_blank" rel="archives" href="//www.twitter.com/#!/slims_official">Twitter</a></li>
          <li><a target="_blank" rel="archives" href="//www.youtube.com/user/senayanslims">Youtube</a></li>
          <li><a target="_blank" rel="archives" href="//www.github.com/slims">Github</a></li>
          <li><a target="_blank" rel="archives" href="//www.slims.web.id/forum">Forum</a></li>
          <li><a target="_blank" rel="archives" href="index.php?rss=true" title="RSS" class="rss" >RSS</a></li>
        </ul>
      </nav>
    </div>
  </div>
</footer>
<aside class="s-chat">
  <a id="show-pchat" class="s-pchat-toggle animated bounceInRight delay8" role="navigation" >
    <i class="fa fa-comment-o"></i>
    
  </a>
  <div class="s-chat-header">
  Chat With Librarian  </div>
    <div class="s-chat-content text-center">
    <form action="" method="post">
      <p>Please type your name before starting in conversations.</p>
      <hr>
      <label for="message">Your Name:</label>
      <input type="text" id="message" name="userchat" />
      <button type="submit" class="btn btn-block">Start Conversation</button>  
    </form>
  </div>
  <footer class="text-center">You may also hit Enter button to starting in conversation. </footer>
  </aside>

<script>
  $.get('chatserver.php', {}, function(){});
  var Server;
  function log( text ) {
    $log = $('#log');
    //Add text to log
    $log.append(($log.html()?'<br>':'') + text);
    //Autoscroll
    //$log[0].scrollTop = $log[0].scrollHeight - $log[0].clientHeight;
  }

  function send( text ) {
    Server.send( 'message', text );
  }

  $(document).ready(function() {
    log('Connecting...');
    Server = new FancyWebSocket('ws://127.0.0.1:9300?u=');
    $('#message').keypress(function(e) {
      if ( e.keyCode == 13 && this.value ) {
        log( 'You: ' + this.value );
        send( '[M] |' + this.value );
        $.ajax({
          type: 'POST',
          url: 'index.php?p=chat',
          data: {msg: '2022.08.01 06:17:22 [M]  - ' + this.value}
        });
        $(this).val('');
      }
    });

    //Let the user know we're connected
    Server.bind('open', function() {
      log( "Connected." );
    });

    //OH NOES! Disconnection occurred.
    Server.bind('close', function( data ) {
      log( "Disconnected." );
    });

    //Log any messages sent from server
    Server.bind('message', function( payload ) {
      log( payload );
      $('#log').scrollTop($('#log')[0].scrollHeight);
    });

    Server.connect();
  });

</script>
<!-- Background 
============================================= -->
<div class="s-background animated fadeIn">

  <!-- Gradient Effect 
  ============================================= -->
  <div class="gradients">
        <div class="blue"></div>
  </div>


      <img class="slider" src='template/default/img/4.jpg'/>
    <img class="slider" src='template/default/img/3.jpg'/>
    <img class="slider" src='template/default/img/2.jpg'/>
    <img class="slider" src='template/default/img/1.jpg'/>
  
</div>


<script>
  
  //Replace blank cover
  $('.book img').error(function(){
    var title = $(this).parent().attr('title').split(' ');
    $(this).parent().append('<div class="s-feature-title">' + title[0] + '<br/>' + title[1] + '<br/>... </div>');
    $(this).attr({
      src   : './template/default/img/book.png',  
      title : title + title[0] + ' ' + title[1]
    });
  });

  //Replace blank photo
  $('.librarian-image img').error(function(){
    $(this).attr('src','./template/default/img/avatar.jpg');
  });

  //Feature list slider
  function mycarousel_initCallback(carousel)
  {
    // Disable autoscrolling if the user clicks the prev or next button.
    carousel.buttonNext.bind('click', function() {
      carousel.startAuto(0);
    });

    carousel.buttonPrev.bind('click', function() {
      carousel.startAuto(0);
    });

    // Pause autoscrolling if the user moves with the cursor over the clip.
    carousel.clip.hover(function() {
      carousel.stopAuto();
    }, function() {
      carousel.startAuto();
    });
  };

  jQuery('#topbook').jcarousel({
      auto: 5,
      wrap: 'last',
      initCallback: mycarousel_initCallback
  });

$(window).scroll(function() {    
  console.log($(window).scrollTop());
  if ($(window).scrollTop() > 50) {
    $('.s-main-search').removeClass("animated fadeIn").addClass("animated fadeOut");
  } else {
    $('.s-main-search').removeClass("animated fadeOut").addClass("animated fadeIn");
  }  
});

</script>

</body>
</html><?php /**PATH C:\Users\User\perpustakaanTA\resources\views/template/guest.blade.php ENDPATH**/ ?>