<?php $__env->startSection('content'); ?>
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-12 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-12">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-11">
                                    <h2 class="card-title text-primary">Tambah Data Penerbit</h2>
                                </div>
                                <div class="col-md-1">
                                    <a href="/admin/penerbit" class="btn btn-md btn-block btn-primary"><i class="bx bx-left-arrow-alt"></i></a>
                                </div>
                            </div>
                          <hr>
                          <form action="/admin/penerbit/create" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label>Nama Penerbit</label>
                                    <input type="text" name="nama" class="form-control" place_holder="Masukan Nama Penerbit...." value="">
                                </div>
                                
                                <div class="form-group mb-3">
                                    <label>Lokasi Penerbit</label>
                                    <input type="text" name="lokasi" class="form-control" place_holder="Masukan Lokasi Penerbit...." value="">
                                </div>
                                <br>
                                <button class="btn btn-primary" type="submit">Tambah Data</button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', [
    'activePage' => 'master',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\perpustakaanTA\resources\views/admin/penerbit/tambah.blade.php ENDPATH**/ ?>