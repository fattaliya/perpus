<!doctype html>
<html lang="en">
  <head>
  	<title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i&display=swap" rel="stylesheet">

	
	<link rel="stylesheet" href="<?php echo e(asset('assets/home/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/home/css/owl.theme.default.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/home/ionicons/css/ionicons.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/home/css/style.css')); ?>">
  </head>
  <body>

	<nav class="navbar navbar-expand-lg navbar-detached navbar-dark" style="background-color:#001746;">
		<div class="container">
		<a class="navbar-brand" href="<?php echo e(route('index')); ?>">
			<img src="assets/img/logos/smk.png" width="40" alt="logo"  class="mb-0 font-sans-serif fw-bold fs-md-5 fs-lg-1">
		</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
		  <ul class="navbar-nav mr-auto">
			<li class="navbar-brand nav-item">
			  <a class="nav-link" href="<?php echo e(route('login')); ?>">SMK NEGERI 1 BATIPUH</a>
			</li>
		  </ul>
		  <ul class="nav navbar-nav ml-auto">
			<?php if(auth()->guard()->guest()): ?>
			 <li class="nav-item">
			  <a href="<?php echo e(url('/masuk')); ?>" class="btn btn-outline-success">Register </a>
			</li>
			



			<?php else: ?>
			<li class="nav-item dropdown">
			  <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
				<?php echo e(Auth::user()->name); ?>

			  </a>
			  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
				<a href="/admin" class="dropdown-item">Dashboard</a>
				<a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"> <?php echo e(__('Logout')); ?> </a>
				<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
				  <?php echo csrf_field(); ?>
				</form>
			  </div>
			</li>
			<?php endif; ?>

		  </ul>
		</div>
	</div>
	</nav>


	<div class="jumbotron jumbotron-fluid">
        <form method="GET" action="cari">
		<?php echo csrf_field(); ?>
        <div class="container">
          <h1 class="display-4 text-center">Pencarian Buku</h1>
          <p class="lead text-center">Kamu bisa mencari Buku apapun yang kamu mau.</p>
          <div class="input-group mb-3">
              <input type="text" class="form-control" name="cari" placeholder="Cari Buku" value="<?php echo e(old('cari')); ?>" aria-label="Recipient's username" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" href="/admin/kategori"> Cari </button>
              </div>

            </div>
        </div>
      </div>

		<section class="ftco-section">
			<div class="container">
				<div class="row mb-5">
					<div class="col-md-12">
						<h2 class="heading-section mb-2">Koleksi sering dipinjam</h2>
					</div>
					<div class="col-md-12">
						<div class="featured-carousel owl-carousel">
							<?php $__currentLoopData = App\Buku::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<div class="work">
									<div class="img d-flex align-items-end justify-content-center" style="background-image: url(/foto/<?php echo e($data->foto); ?>);">
										<div class="text w-100">
											<span class="cat"><?php echo e($data->kategori); ?></span>
											<h3><a href="#"><?php echo e($data->judul); ?></a></h3>
											<h4>Stok : <?php echo e($data->stok); ?></h4>
										</div>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = App\Buku::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<div class="work">
									<div class="img d-flex align-items-end justify-content-center" style="background-image: url(/foto/<?php echo e($data->foto); ?>);">
										<div class="text w-100">
											<span class="cat"><?php echo e($data->kategori); ?></span>
											<h3><a href="#"><?php echo e($data->judul); ?></a></h3>
											<h4>Stok : <?php echo e($data->stok); ?></h4>
										</div>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
				<div class="row bg-light">
					<div class="col-md-12">
						<h2 class="heading-section mb-2">Koleksi terbaru</h2>
					</div>
					<div class="col-md-12">
						<div class="featured-carousel owl-carousel">
							<?php $__currentLoopData = App\Buku::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<div class="work">
									<div class="img d-flex align-items-end justify-content-center" style="background-image: url(/foto/<?php echo e($data->foto); ?>);">
										<div class="text w-100">
											<span class="cat"><?php echo e($data->kategori); ?></span>
											<h3><a href="#"><?php echo e($data->judul); ?></a></h3>
											<h4>Stok : <?php echo e($data->stok); ?></h4>
										</div>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</section>
    </form>
    <script src="<?php echo e(asset('assets/home/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/home/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/home/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/home/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/home/js/main.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\Users\User\perpustakaanTA\resources\views/template/index.blade.php ENDPATH**/ ?>