<?php $__env->startSection('content'); ?>
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-12 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-12">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-11">
                                    
                                    <a href="/admin/peminjaman/print_peminjaman" class="btn btn-md btn-block btn-success"><i class="fa fa-print"></i> Print</a>
                                </div>
                                <div class="col-md-1">
                                    <a href="/admin/peminjaman/add" class="btn btn-md btn-block btn-primary"><i class="bx bx-plus"></i></a>
                                </div>
                            </div>
                          <hr>
<div class="row" style="margin-top: 20px;">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">List Data Peminjaman</h4>
                    <div class="table-responsive">
                      <table class="table table-striped" id="table">
                         <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Peminjam</th>
                                    <th>BUKU</th>
                                    <th>Tanggal Pinjam</th>
                                    <th>Tanggal Kembali</th>
                                    <th>Tanggal Pengembalian</th>

                                    
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                  $buku = DB::table('buku')->find($data->id_buku);
                                ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    
                                    <td><?php echo e(DB::table('data_siswa')->where('id',$data->id_siswa)->value('nama_siswa')); ?></td>
                                    <td><?php echo e(DB::table('buku')->where('id',$data->id_buku)->value('judul')); ?></td>
                                    <td><?php echo e($data->tanggal_pinjam); ?></td>
                                    <td><?php echo e($data->tanggal_kembali); ?></td>
                                    <td><?php echo e($data->tanggal_pengembalian); ?></td>
                                    

                                <td class="text-center">
                                    <a href="/admin/peminjaman/edit/<?php echo e($data->id); ?>" class="btn btn-sm btn-secondary"><i class="bx bx-pencil"></i></a><br> <br>
                                    <a href="/admin/peminjaman/getKehilangan/<?php echo e($data->id); ?>" class="btn btn-sm btn-secondary"><i class="bx bx-bell-minus"></i></a><br><br>


                                    

                                



                                <?php if(!is_null($data->tanggal_pengembalian)): ?>

                                
                                    <form method="POST">
                                        <?php echo csrf_field(); ?>

                                        <button type="button" class="btn btn-outline-secondary btn-sm" disabled><?php echo e($data->status_peminjaman); ?></button>

                                    </form>
                                    </a>
                                <?php else: ?>
                                <?php if($data->tanggal_pengembalian>=date("Y-m-d")): ?>
                                    <a href="/admin/peminjaman/kembali/<?php echo e($data->id); ?>" method="get"class="-inline"~ onclick="return confirm('apakah buku sudah sesuai');" >
                                        <form method="POST">
                                            <?php echo csrf_field(); ?>
                                        <button type="button" class="btn btn-outline-info btn-sm"> Belum  Kembalikan</button>
                                        </form>
                                    </a>
                                    <?php else: ?>
                                    <a href="/admin/peminjaman/getdenda/<?php echo e($data->id); ?>">
                                        <form method="POST">
                                            <?php echo csrf_field(); ?>
                                        <button type="button" class="btn btn-outline-info btn-sm"> Belum  Kembalikan</button>
                                        </form>
                                    </a>
                                    <?php endif; ?>

                                <?php endif; ?>


                                


                                    

                                    </td>

                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', [
    'activePage' => 'master',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\perpustakaanTA\resources\views/admin/peminjaman/index.blade.php ENDPATH**/ ?>