<?php $__env->startSection('content'); ?>
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-12 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-12">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-11">
                                    <h2 class="card-title text-primary">Edit Data Buku</h2>
                                </div>
                                <div class="col-md-1">
                                    <a href="/admin/buku" class="btn btn-md btn-block btn-primary"><i class="bx bx-left-arrow-alt"></i></a>
                                </div>
                            </div>
                          <hr>

                          <form action="/admin/buku/update/<?php echo e($buku->id); ?>"  enctype="multipart/form-data" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label>NIB</label>
                                    <input type="text" name="nib" class="form-control" place_holder="Masukan Kode buku..." value="<?php echo e($buku->nib); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Terima Tanggal</label>
                                    <input type="date" name="terima_tanggal" class="form-control" place_holder="Masukan Terima Tanggal..." value="<?php echo e($buku->terima_tanggal); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Judul</label>
                                    <input type="text" name="judul" class="form-control" place_holder="Masukan Judul buku...." value="<?php echo e($buku->judul); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Kategori</label>
                                    <select class="form-control" name="id_kategori" required>
                                      <option value="">-- Pilih Kategori --</option>
                                      <?php $__currentLoopData = \DB::table('kategori')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group mb-3">
                                    <label>Pengarang</label>
                                    <input type="text" name="pengarang" class="form-control" place_holder="Masukan Tempat Terbit...." value="<?php echo e($buku->pengarang); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Penerbit</label>
                                    <input type="text" name="penerbit" class="form-control" place_holder="Masukan Tempat Terbit...." value="<?php echo e($buku->pengarang); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Lokasi</label>
                                    <input type="text" name="lokasi" class="form-control" place_holder="Masukan Tempat Terbit...." value="<?php echo e($buku->lokasi); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>EXP</label>
                                    <input type="text" name="exp" class="form-control" place_holder="Masukan Tempat Terbit...." value="<?php echo e($buku->exp); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>CNB</label>
                                    <input type="text" name="cnb" class="form-control" place_holder="Masukan Terima Tanggal..." value="<?php echo e($buku->cnb); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Asal Buku</label>
                                    <input type="text" name="asal_buku" class="form-control" place_holder="Masukan Terima Tanggal..." value="<?php echo e($buku->asal_buku); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Tempat Terbit</label>
                                    <input type="text" name="tempat_terbit" class="form-control" place_holder="Masukan Tempat Terbit...." value="<?php echo e($buku->tempat_terbit); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Stok</label>
                                    <input type="text" name="stok" class="form-control" place_holder="Masukan Id Pengarang...." value="<?php echo e($buku->stok); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Ketersedian</label>
                                    <input type="text" name="ketersedian" class="form-control" place_holder="Masukan Terima Tanggal..." value="<?php echo e($buku->ketersedian); ?>">
                                </div>
                                
                                <br>
                                <button class="btn btn-success" type="submit">Update Data</button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', [
    'activePage' => 'master',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\perpustakaanTA\resources\views/admin/buku/edit.blade.php ENDPATH**/ ?>