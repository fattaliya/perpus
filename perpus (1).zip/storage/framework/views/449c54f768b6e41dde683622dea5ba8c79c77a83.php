<div style="background-color: #e9ecef;padding:50px;border-radius: 20px">

<h5 class=" mb-2">Hasil Pencarian Kategori : <b><i><u><?php echo e(ucwords($q)); ?></u></i></b></h5>

<i class="text-danger" style="font-weight: 600;font-size: 12px">#Ditemukan <?php echo e(count($buku)); ?> buku untuk kategori ini ..</i>

<hr>
<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-lg-2 col-md-2" >
        <div class="item">
            <div class="work">
                <div class="img d-flex align-items-end justify-content-center" style="background-image: url(/foto/<?php echo e($data->foto); ?>);">
                    <div class="text w-100">
                        <span class="cat" style="font-size: 8px"><?php echo e($data->nama); ?></span>
                        <h3><a href="#"><?php echo e(ucwords($data->judul)); ?></a></h3>
                        <h4>Stok : <b><?php echo e($data->stok); ?></b></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-lg-12" >
        <h6 class="text-danger text-center" style="font-weight: 700">Buku untuk Kategori <i><u><?php echo e($q); ?></u></i> tidak ditemukan</h6>
    </div>
    <?php endif; ?>
</div>


</div>
<?php /**PATH D:\App\Laravel\pj\perpustakaanTA\perpus\resources\views/template/cari.blade.php ENDPATH**/ ?>