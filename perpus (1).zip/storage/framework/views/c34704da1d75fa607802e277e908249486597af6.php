<?php $__env->startSection('content'); ?>
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-12 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-12">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-11">
                                    
                                    <a href="/admin/data_siswa/print_data_anggota" class="btn btn-md btn-block btn-success"><i class="fa fa-print"></i> Print</a>
                                </div>
                                <div class="col-md-1">
                                    <a href="/admin/data_siswa/add" class="btn btn-md btn-block btn-primary"><i class="bx bx-plus"></i></a>
                                </div>
                                <div class="col-auto">
                                    <div class="col card-header text-right">
                                    <form action="/admin/data_siswa/cari" method="GET">
                                        <input type="text" name="cari" placeholder="Cari Nama Anggota .." value="<?php echo e(old('cari')); ?>">
                                        <input type="submit" value="cari">
                                    </form>
                                </div>
                            </div>
                          <hr>
<div class="row" style="margin-top: 20px;">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">List Data Anggota</h4>
                    <div class="table-responsive">
                        <table class="table table-striped" id="table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                     <th>Status</th>
                                    <th>nis</th>
                                    <th>Nama</th>
                                    
                                    <th>Jenis Kelamin</th>
                                    <th>No WA</th>
                                    <th>Status</th>
                                    <th>Status Akun</th>
                                    <th>Foto</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                                <?php $no = 1; ?>
                                <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                //   $kelas = DB::table('kelas')->find($data->id_kelas);

                                ?>

                                <tr>

                                    <td><?php echo e($no++); ?></td>
                                    <td>
                                        <?php if($data->status_akun == 1): ?>
                                            <a href="<?php echo e(url('/admin/data_siswa/status_akun/' .$data->id)); ?>" class="btn btn-sm btn-danger">Non-Aktifkan</a>
                                        <?php else: ?>
                                        <a href="<?php echo e(url('/admin/data_siswa/status_akun/' .$data->id)); ?>" class="btn btn-sm btn-success">Aktifkan</a>
                                        <?php endif; ?>
                                </td>
                                    <td><?php echo e($data->nis); ?></td>
                                    <td><?php echo e($data->nama_siswa); ?></td>
                                    
                                    <td><?php echo e($data->jenis_kelamin); ?></td>
                                    <td><?php echo e($data->no_wa); ?></td>
                                    <td><?php echo e($data->status); ?></td>
                                    <td><label class="label label-success"> <?php echo e(($data->status_akun == 1) ? 'Aktif' : 'Tidak Aktif'); ?></label></td>
                                    <td>
                                      <img src="/foto/<?php echo e($data->foto); ?>" alt="<?php echo e($data->foto); ?>" width="200"/>
                                    </td>
                                    <td class="text-center">
                                        <a href="/admin/data_siswa/edit/<?php echo e($data->id); ?>" class="btn btn-sm btn-success"><i class="bx bx-pencil"></i></a>
                                        <form action="/admin/data_siswa/delete/<?php echo e($data->id); ?>" method="get" class="-inline" onsubmit="return confirm('Yakin anda mau menghapus')">
                                            <br>
                                            <form method="POST"><form method="POST">
                                              <?php echo csrf_field(); ?>
                                              <button class="btn btn-danger btn-sm">
                                              <i class="bx bx-trash"></i>
                                              </button>
                                            </form>
                                            <br>
                                      <a href="/admin/data_siswa/detail/<?php echo e($data->nis); ?>" class="btn btn-sm btn-primary"><i class="bx bxs-show"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <?php echo e($data_siswa->links()); ?>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', [
    'activePage' => 'master',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\perpustakaanTA\resources\views/admin/data_siswa/index.blade.php ENDPATH**/ ?>