
<?php $__env->startSection('content'); ?>
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-12 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-12">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-11">
                                    <h2 class="card-title text-primary">Edit kehilangan</h2>
                                </div>
                                <div class="col-md-1">
                                    <a href="/admin/peminjaman" class="btn btn-md btn-block btn-primary"><i class="bx bx-left-arrow-alt"></i></a>
                                </div>
                            </div>
                          <hr>
                          <form action="/admin/peminjaman/kehilangan" method="POST">
                                <?php echo csrf_field(); ?>
                                
                                <div class="form-group mb-3">
                                    <input type="text" name="id" class="form-control" place_holder="Masukan Judul peminjaman...." value="<?php echo e($peminjaman->id); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <input type="text" name="id_buku" class="form-control" place_holder="Masukan Judul peminjaman...." value="<?php echo e($peminjaman->id_buku); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <input type="text" name="kehilangan" class="form-control" place_holder="Masukan Judul peminjaman...." value="<?php echo e($kategori->kehilangan); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Nama Buku yang Hilang</label>
                                    <input type="text" name="judul" class="form-control" place_holder="Masukan Judul peminjaman...." value="<?php echo e($buku->judul); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Tanggal Pinjam</label>
                                    <input type="date" name="tanggal_pinjam" class="form-control" place_holder="Masukan Judul peminjaman...." value="<?php echo e($peminjaman->tanggal_pinjam); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Tanggal Laporan</label>
                                    <input type="date" name="tanggal_lapor" class="form-control" place_holder="Masukan Judul peminjaman...." value="<?php echo e($tgllapor); ?>">
                                </div>
                                <div class="form-group mb-3">
                                    <label>Alasan</label>
                                    <input type="text" name="alasan" class="form-control" place_holder="Masukan Judul peminjaman...." value="">
                                </div>
                                <?php if($kategori->kehilangan == "Buku" ||$kategori->kehilangan == "buku" ): ?>

                                    <div class="form-group mb-3">
                                        <label>Judul Buku Pengganti</label>
                                        <input type="text" name="pengganti" class="form-control" place_holder="Masukan Judul peminjaman...." value="">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label>Pengarang</label>
                                        <input type="text" name="pengarang" class="form-control" place_holder="Masukan Judul peminjaman...." value="">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label>Penerbit</label>
                                        <input type="text" name="penerbit" class="form-control" place_holder="Masukan Judul peminjaman...." value="">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label>Lokasi</label>
                                        <input type="text" name="lokasi" class="form-control" place_holder="Masukan Judul peminjaman...." value="">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label>Tempat Terbit</label>
                                        <input type="text" name="tempat_terbit" class="form-control" place_holder="Masukan Judul peminjaman...." value="">
                                    </div>

                                <?php else: ?>
                                <div class="form-group mb-3">
                                    <label>Nominal Uang Pengganti</label>
                                    <input type="text" name="pengganti" class="form-control" place_holder="Masukan Judul peminjaman...." value="<?php echo e($kategori->jumlah); ?>" readonly>
                                </div>
                                <?php endif; ?>

                                

                                <br>
                                <button class="btn btn-success" type="submit">Update Data</button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', [
    'activePage' => 'master',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\perpustakaanTA\resources\views/admin/peminjaman/kehilangan.blade.php ENDPATH**/ ?>