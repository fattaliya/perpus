<html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- Custom fonts for this template-->
        <link href="<?php echo e(asset('../admin/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
        <link
            href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
            rel="stylesheet">

        <!-- Custom styles for this template-->
        <link href="<?php echo e(asset('../admin/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
        <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>">

    </head>
    <body onload="window.print()">
    <div id="content">


      <!-- Begin Page Content -->
      <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h5 mb-2 text-gray-800 font-weight-bold">Data Anggota</h1>
          <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
          <?php endif; ?>

          <?php if(session('delete_status')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Success!</strong> <?php echo e(session('delete_status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
          <?php endif; ?>

          <!-- DataTales Example -->

<!-- DataTales Example -->
<div class="card shadow mb-12">
    <div class="card-body">
        <div class="table-responsive">

            <div class="box-body">
                <div class="table-responsive">
                <table class="table table-stripped">
                <table border="1" align="center">
                    <tr>

                    <td><center>
                        <font size="3"><b> SMK NEGERI 1 BATIPUH</font><br>
                        <font size="3"><i>Alamat : Jl. Raya Padang Panjang – Solok</i></font><br>
                        <font size="3">Km. 6. 5 Baruah, Kec. Batipuh, Kab. Tanah Datar, Sumbar, 27265 </font><br>
                    </td>
                    </tr><br>
                    <tr>
                        <td colspan="8"<hr> </td>
                    </td>
                    <br>
                    <br>
                    <table align="center">
                        <tr>
                            <th>No</th>
                            <th>nis</th>
                            <th>Nama</th>
                            
                            <th>Jenis Kelamin</th>
                            <th>Status</th>
                        </tr>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        //   $kelas = DB::table('kelas')->find($data->id_kelas);
                        ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($data->nis); ?></td>
                            <td><?php echo e($data->nama_siswa); ?></td>
                            
                            <td><?php echo e($data->jenis_kelamin); ?></td>
                            <td><?php echo e($data->status); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                         </table>
                    </table>
                 <div class="col-md-12" align="center">
            </div>

        </div>
     </div>

     </div>
</div>

 </div>


      <!-- /.container-fluid -->
  </div>
<!-- End of Main Content -->
<script src="<?php echo e(asset('../admin/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('../admin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('../admin/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('../admin/js/sb-admin-2.min.js')); ?>"></script>

<!-- Page level plugins -->
<script src="<?php echo e(asset('../admin/vendor/chart.js/Chart.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('../admin/js/demo/chart-area-demo.js')); ?>"></script>
<script src="<?php echo e(asset('../admin/js/demo/chart-pie-demo.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\Users\User\perpustakaanTA\resources\views/admin/data_siswa/print_data_anggota.blade.php ENDPATH**/ ?>