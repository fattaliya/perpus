<?php $__env->startSection('js'); ?>
 <script type="text/javascript">
   $(document).on('click', '.pilih', function (e) {
                document.getElementById("buku_judul").value = $(this).attr('data-buku_judul');
                document.getElementById("buku_id").value = $(this).attr('data-buku_id');
                $('#myModal').modal('hide');
            });

            $(document).on('click', '.pilih_data_siswa', function (e) {
                document.getElementById("data_siswa_id").value = $(this).attr('data-data_siswa_id');
                document.getElementById("data_siswa_nama").value = $(this).attr('data-data_siswa_nama');
                $('#myModal2').modal('hide');
            });

             $(function () {
                $("#lookup, #lookup2").dataTable();
            });

        </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-lg-12 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-sm-12">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-11">

<form method="POST" action="<?php echo e(route('transaksi.store')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

<div class="row">
            <div class="col-md-5 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-12">
                       <h4 class="card-title">Tambah Transaksi baru</h4>

                        <div class="form-group<?php echo e($errors->has('kode_transaksi') ? ' has-error' : ''); ?>">
                            <label for="kode_transaksi" class="col-md-12 control-label">Kode Transaksi</label>
                            <div class="col-md-12">
                                <input id="kode_transaksi" type="text" class="form-control" name="kode_transaksi" value="<?php echo e($kode); ?>" required readonly="">
                                <?php if($errors->has('kode_transaksi')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('kode_transaksi')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group<?php echo e($errors->has('tgl_pinjam') ? ' has-error' : ''); ?>">
                            <label for="tgl_pinjam" class="col-md-12 control-label">Tanggal Pinjam</label>
                            <div class="col-md-12">
                                <input id="tgl_pinjam" type="date" class="form-control" name="tgl_pinjam" value="<?php echo e(date('Y-m-d', strtotime(Carbon\Carbon::today()->toDateString()))); ?>" required <?php if(Auth::user()->level == 'user'): ?> readonly <?php endif; ?>>
                                <?php if($errors->has('tgl_pinjam')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tgl_pinjam')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group<?php echo e($errors->has('tgl_kembali') ? ' has-error' : ''); ?>">
                            <label for="tgl_kembali" class="col-md-12 control-label">Tanggal Kembali</label>
                            <div class="col-md-12">
                                <input id="tgl_kembali" type="date"  class="form-control" name="tgl_kembali" value="<?php echo e(date('Y-m-d', strtotime(Carbon\Carbon::today()->addDays(5)->toDateString()))); ?>" required="" <?php if(Auth::user()->level == 'user'): ?> readonly <?php endif; ?>>
                                <?php if($errors->has('tgl_kembali')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tgl_kembali')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('buku_id') ? ' has-error' : ''); ?>">
                            <label for="buku_id" class="col-md-4 control-label">Buku</label>
                            <div class="col-md-12">
                                <div class="input-group">
                                <input id="buku_judul" type="text" class="form-control" readonly="" required>
                                <input id="buku_id" type="hidden" name="buku_id" value="<?php echo e(old('buku_id')); ?>" required readonly="">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-info btn-secondary" data-toggle="modal" data-target="#myModal"><b>Cari Buku</b> <span class="fa fa-search"></span></button>
                                </span>
                                </div>
                                <?php if($errors->has('buku_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('buku_id')); ?></strong>
                                    </span>
                                <?php endif; ?>

                            </div>
                        </div>


                        <?php if(Auth::user()->level == 'admin'): ?>
                        <div class="form-group<?php echo e($errors->has('data_siswa_id') ? ' has-error' : ''); ?>">
                            <label for="data_siswa_id" class="col-md-4 control-label">Data Siswa</label>
                            <div class="col-md-12">
                                <div class="input-group">
                                <input id="data_siswa_nama" type="text" class="form-control" readonly="" required>
                                <input id="data_siswa_id" type="hidden" name="data_siswa_id" value="<?php echo e(old('data_siswa_id')); ?>" required readonly="">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-warning btn-secondary" data-toggle="modal" data-target="#myModal2"><b>Cari Data Siswa</b> <span class="fa fa-search"></span></button>
                                </span>
                                </div>
                                <?php if($errors->has('data_siswa_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('data_siswa_id')); ?></strong>
                                    </span>
                                <?php endif; ?>

                            </div>
                        </div>
                        <?php else: ?>
                        <div class="form-group<?php echo e($errors->has('data_siswa_id') ? ' has-error' : ''); ?>">
                            <label for="data_siswa_id" class="col-md-4 control-label">Data Siswa</label>
                            <div class="col-md-12">
                                  <input id="data_siswa_nama" type="text" class="form-control" readonly="" value="" required>
                                  <input id="data_siswa_id" type="hidden" name="data_siswa_id" value="" required readonly="">
                                <?php if($errors->has('data_siswa_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('data_siswa_id')); ?></strong>
                                    </span>
                                <?php endif; ?>

                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="form-group<?php echo e($errors->has('ket') ? ' has-error' : ''); ?>">
                            <label for="ket" class="col-md-4 control-label">Keterangan</label>
                            <div class="col-md-12">
                                <input id="ket" type="text" class="form-control" name="ket" value="<?php echo e(old('ket')); ?>">
                                <?php if($errors->has('ket')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('ket')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary" id="submit">
                                    Submit
                        </button>
                        <button type="reset" class="btn btn-danger">
                                    Reset
                        </button>
                        <a href="<?php echo e(route('transaksi.index')); ?>" class="btn btn-light pull-right">Back</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

</div>
</form>


  <!-- Modal -->
        <div class="modal fade bd-example-modal-lg" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" >
  <div class="modal-dialog modal-lg" role="document" >
    <div class="modal-content" style="background: #fff;">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cari Buku</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
                        <table id="lookup" class="table table-bordered table-hover table-striped">
                            <thead>
                                <tr>
                                    <th>Judul</th>
                                    <th>ISBN</th>
                                    <th>Pengarang</th>
                                    <th>Tahun</th>
                                    <th>Stok</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="pilih" data-buku_id="<?php echo $data->id; ?>" data-buku_judul="<?php echo $data->judul; ?>" >
                                    <td><?php if($data->cover): ?>
                            <img src="<?php echo e(url('images/buku/'. $data->cover)); ?>" alt="image" style="margin-right: 10px;" />
                          <?php else: ?>
                            <img src="<?php echo e(url('images/buku/default.png')); ?>" alt="image" style="margin-right: 10px;" />
                          <?php endif; ?>
                          <?php echo e($data->judul); ?></td>
                                    <td><?php echo e($data->isbn); ?></td>
                                    <td><?php echo e($data->pengarang); ?></td>
                                    <td><?php echo e($data->tahun_terbit); ?></td>
                                    <td><?php echo e($data->jumlah_buku); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


  <!-- Modal -->
        <div class="modal fade bd-example-modal-lg" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" >
  <div class="modal-dialog modal-lg" role="document" >
    <div class="modal-content" style="background: #fff;">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cari data_siswa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
                        <table id="lookup" class="table table-bordered table-hover table-striped">
                            <thead>
                        <tr>
                          <th>
                            Nama
                          </th>
                          <th>
                            NPM
                          </th>
                          <th>
                            Prodi
                          </th>
                          <th>
                            Jenis Kelamin
                          </th>
                        </tr>
                      </thead>
                            <tbody>
                                <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="pilih_data_siswa" data-data_siswa_id="<?php echo $data->id; ?>" data-data_siswa_nama="<?php echo $data->nama; ?>" >
                                    <td class="py-1">
                          

                            <?php echo e($data->nama); ?>

                          </td>
                          <td>
                            <?php echo e($data->npm); ?>

                          </td>

                          <td>
                          <?php if($data->prodi == 'TI'): ?>
                            Teknik Informatika
                          <?php elseif($data->prodi == 'SI'): ?>
                            Sistem Informasi
                          <?php else: ?>
                            Kesehatan Masyarakat
                          <?php endif; ?>
                          </td>
                          <td>
                            <?php echo e($data->jk === "L" ? "Laki - Laki" : "Perempuan"); ?>

                          </td>
                        </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\perpustakaanTA\resources\views/admin/transaksi/create.blade.php ENDPATH**/ ?>